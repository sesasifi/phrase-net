Protótipo Phrase Nets (MVP)
Arquivos:
- index.html
- styles.css
- script.js

Como usar:
1. Baixe os três arquivos para a mesma pasta.
2. Abra o arquivo index.html no navegador (Chrome/Firefox).
3. Cole um texto no campo, ajuste parâmetros e clique "Gerar Phrase Net".
4. Use "Exportar JSON" para salvar os nós/arestas ou "Salvar SVG" para baixar a imagem.

Observações:
- Processamento totalmente client-side (sem backend).
- Para textos muito grandes, o navegador pode ficar lento — use topN para limitar nós.
- Implementa coocorrência em janela e coocorrência por frase. Não implementa parsing sintático (dep.).
